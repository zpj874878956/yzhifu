<?php
define('authcode','fe1e929dc12278b4430ba542059dcb80');

?>