<?php
$config['notify_url']	= "http://".$_SERVER['HTTP_HOST']."/notify_url.php";//异步通知地址
$config['return_url']	= "http://".$_SERVER['HTTP_HOST']."/return_url.php";//同步跳转地址
$config['apiurl']       = "不用填";//请求地址